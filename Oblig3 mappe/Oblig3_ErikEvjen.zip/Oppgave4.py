# Lager en funksjon med lengde, bredde og høyde som parameter.
# Returner så og printer formellen.
def volume(lenght, width, height):
    return print(f"\nVolum: lengde * bredde * høyde\n{lenght} * {width} * {height} = {lenght * width * height}")

# Kjører funksjonen
volume(3, 4, 8)
volume(2, 5, 7)
volume(10, 5, 1)

