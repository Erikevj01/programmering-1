# Lager en variabel for hvor mange hver person har spist
person_1 = 5
person_2 = 9
person_3 = 2.5
person_4 = 21
person_5 = 0

# Variabler for hvor mange som er spist totalt og hvor mange personer
total_amount_eaten = person_1 + person_2 + person_3 + person_4 + person_5
amount_of_persons = 5

# Variabel for gjennomsnittlige antall spiste småkaker
average_amount_eaten = total_amount_eaten / amount_of_persons

# Skriver ut gjennomsnittlige antall spiste småkaker som int
print(f"Average amount of cookies eaten: {int(average_amount_eaten)}")

