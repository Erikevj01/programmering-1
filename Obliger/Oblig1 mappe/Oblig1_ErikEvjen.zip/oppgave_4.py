# Lager de tre variablene
a, b, c = 6, 3, 2

# Skriver ut og viser variablene
print("Variables:")
print("a=6")
print("b=3")
print("c=2")

# Skriver ut regnestykkene med variablene
print(f"a) a + b * c = {a + b * c}")
print(f"b) (a + b) * c = {(a + b) * c}")
print(f"c) a / b / c = {a / b / c}")
print(f"d) a / (b / c) = {a / (b / c)}")
