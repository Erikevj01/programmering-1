# Skriver ut Hello, World!
print("Hello, World!")
