# Lager tre variabler for fornavn, etternavn og alder
first_name = "Erik"
last_name = "Evjen"
age = "21"

# Skriver ut de tre variablene inn i settningen som ble gitt
print(f"Hei. Jeg heter {first_name} {last_name} og er {age} år gammel")