# Oppretter funksjonen som skal ta imot en liste som parameter.
def print_list(log):
    for value in log:
        print(value)

# Lager en liste med mine favoritt matretter
favorite_dishes = ["Pizza", "Taco", "Tapas"]

# Kjører funksjonen
print("Mine favoritt matretter:\n")
print_list(favorite_dishes)


